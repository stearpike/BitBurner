/** @param {NS} ns **/
export async function main(ns) {
    ns.disableLog("ALL");

    let homePaths = [["home"]];
    let homePath = JSON.parse(JSON.stringify(homePaths[0]));
    let scannedServers, server, newNode, path, pathDuplicate, pathNode, nodeDuplicate;

    // Function to get all paths from 'home' to all other servers
    while (homePath.length !== 0) {
        scannedServers = ns.scan(homePath[homePath.length - 1]);
        newNode = false;
        for (server of scannedServers) {
            nodeDuplicate = false;
            for (pathNode of homePath) {
                if (pathNode === server) {
                    nodeDuplicate = true;
                    break;
                }
            }

            if (!nodeDuplicate) {
                homePath.push(server);
                pathDuplicate = false;
                for (path of homePaths) {
                    if (JSON.stringify(path) === JSON.stringify(homePath)) {
                        pathDuplicate = true;
                        break;
                    }
                }

                if (!pathDuplicate) {
                    homePaths.push(JSON.parse(JSON.stringify(homePath)));
                    newNode = true;
                    break;
                } else {
                    homePath.pop();
                }
            }
        }

        if (!newNode) {
            homePath.pop();
        }
    }

    // Install backdoors on servers not owned which have root access
    for (path of homePaths) {
        server = ns.getServer(path[path.length - 1]);
        if (!server.backdoorInstalled && !server.purchasedByPlayer &&
            ns.hasRootAccess(server.hostname) && ns.getServerRequiredHackingLevel(server.hostname) < ns.getHackingLevel()) {
            for (pathNode of path) {
                await ns.singularity.connect(pathNode);
            }
            await ns.singularity.installBackdoor();
            for (let i = path.length - 2; i >= 0; i--) {
                await ns.singularity.connect(path[i]);
            }
            ns.print(`Backdoor installed on ${server.hostname}`);
        }
    }
    ns.tprint("Backdoors completed");
}
